<?php
require_once 'config.php';
requireLogin();

// Estatisticas
$total_alunos = $pdo->query("SELECT COUNT(*) FROM alunos")->fetchColumn();
$alunos_ativos = $pdo->query("SELECT COUNT(*) FROM alunos WHERE status = 'Ativo'")->fetchColumn();
$alunos_inativos = $pdo->query("SELECT COUNT(*) FROM alunos WHERE status = 'Inativo'")->fetchColumn();
$total_turmas = $pdo->query("SELECT COUNT(*) FROM turmas")->fetchColumn();
$total_faltas = $pdo->query("SELECT COUNT(*) FROM frequencia WHERE presenca = 'Falta'")->fetchColumn();
$total_atestados = $pdo->query("SELECT COUNT(*) FROM atestados")->fetchColumn();
$media_geral = $pdo->query("SELECT AVG(nota) FROM notas")->fetchColumn() ?: 0;

// Frequencia baixa
$freq_baixa = $pdo->query("
    SELECT a.id, a.nome, 
           ROUND(COUNT(CASE WHEN f.presenca = 'Presente' THEN 1 END) * 100.0 / COUNT(*), 1) as freq
    FROM alunos a
    LEFT JOIN frequencia f ON a.id = f.aluno_id
    GROUP BY a.id
    HAVING freq < 75 AND COUNT(f.id) > 0
    ORDER BY freq ASC
    LIMIT 5
")->fetchAll();

// Ultimos alunos
$ultimos_alunos = $pdo->query("
    SELECT a.*, t.nome as turma_nome 
    FROM alunos a
    LEFT JOIN turmas t ON a.turma_id = t.id
    ORDER BY a.criado_em DESC LIMIT 5
")->fetchAll();

// Ultimos atestados
$ultimos_atestados = $pdo->query("
    SELECT at.*, a.nome as aluno_nome 
    FROM atestados at
    JOIN alunos a ON at.aluno_id = a.id
    ORDER BY at.criado_em DESC LIMIT 5
")->fetchAll();

include 'header.php';
?>

<!-- Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-slate-500 dark:text-slate-400">Total de Alunos</p>
                <p class="text-2xl font-bold mt-1"><?php echo $total_alunos; ?></p>
            </div>
            <div class="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center text-primary-600">
                <i class="fas fa-users text-lg"></i>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-slate-500 dark:text-slate-400">Alunos Ativos</p>
                <p class="text-2xl font-bold mt-1 text-emerald-600"><?php echo $alunos_ativos; ?></p>
            </div>
            <div class="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl flex items-center justify-center text-emerald-600">
                <i class="fas fa-user-check text-lg"></i>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-slate-500 dark:text-slate-400">Alunos Inativos</p>
                <p class="text-2xl font-bold mt-1 text-rose-600"><?php echo $alunos_inativos; ?></p>
            </div>
            <div class="w-12 h-12 bg-rose-100 dark:bg-rose-900/30 rounded-xl flex items-center justify-center text-rose-600">
                <i class="fas fa-user-times text-lg"></i>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-slate-500 dark:text-slate-400">Total de Turmas</p>
                <p class="text-2xl font-bold mt-1"><?php echo $total_turmas; ?></p>
            </div>
            <div class="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center text-amber-600">
                <i class="fas fa-chalkboard text-lg"></i>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-slate-500 dark:text-slate-400">Total de Faltas</p>
                <p class="text-2xl font-bold mt-1 text-rose-600"><?php echo $total_faltas; ?></p>
            </div>
            <div class="w-12 h-12 bg-rose-100 dark:bg-rose-900/30 rounded-xl flex items-center justify-center text-rose-600">
                <i class="fas fa-calendar-times text-lg"></i>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-slate-500 dark:text-slate-400">Atestados</p>
                <p class="text-2xl font-bold mt-1"><?php echo $total_atestados; ?></p>
            </div>
            <div class="w-12 h-12 bg-violet-100 dark:bg-violet-900/30 rounded-xl flex items-center justify-center text-violet-600">
                <i class="fas fa-file-medical text-lg"></i>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 card-hover sm:col-span-2">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-slate-500 dark:text-slate-400">Media Geral das Notas</p>
                <p class="text-2xl font-bold mt-1 <?php echo $media_geral >= 7 ? 'text-emerald-600' : ($media_geral >= 5 ? 'text-amber-600' : 'text-rose-600'); ?>">
                    <?php echo number_format($media_geral, 2); ?>
                </p>
            </div>
            <div class="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center text-primary-600">
                <i class="fas fa-chart-line text-lg"></i>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Frequencia Baixa -->
    <div class="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
        <div class="p-5 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <i class="fas fa-exclamation-triangle text-rose-500"></i>
                <h3 class="font-bold">Alunos com Frequencia Baixa (&lt; 75%)</h3>
            </div>
            <a href="frequencia.php" class="text-sm text-primary-600 hover:text-primary-700">Ver todos</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-700/50 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                        <th class="px-5 py-3">Aluno</th>
                        <th class="px-5 py-3">Frequencia</th>
                        <th class="px-5 py-3 text-right">Acao</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                    <?php if (empty($freq_baixa)): ?>
                    <tr><td colspan="3" class="px-5 py-8 text-center text-slate-400">Nenhum aluno com frequencia baixa</td></tr>
                    <?php else: foreach ($freq_baixa as $f): ?>
                    <tr class="table-row">
                        <td class="px-5 py-3 font-medium"><?php echo htmlspecialchars($f['nome']); ?></td>
                        <td class="px-5 py-3">
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-300">
                                <?php echo $f['freq']; ?>%
                            </span>
                        </td>
                        <td class="px-5 py-3 text-right">
                            <a href="frequencia.php" class="text-primary-600 hover:text-primary-700 text-sm"><i class="fas fa-eye"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Ultimos Alunos -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
        <div class="p-5 border-b border-slate-200 dark:border-slate-700">
            <h3 class="font-bold flex items-center gap-2"><i class="fas fa-user-plus text-primary-500"></i> Ultimos Alunos</h3>
        </div>
        <div class="divide-y divide-slate-200 dark:divide-slate-700">
            <?php foreach ($ultimos_alunos as $aluno): ?>
            <div class="px-5 py-3 flex items-center justify-between">
                <div>
                    <p class="font-medium text-sm"><?php echo htmlspecialchars($aluno['nome']); ?></p>
                    <p class="text-xs text-slate-500"><?php echo htmlspecialchars($aluno['turma_nome'] ?? 'Sem turma'); ?></p>
                </div>
                <span class="text-xs px-2 py-1 rounded-full <?php echo $aluno['status'] == 'Ativo' ? 'bg-emerald-100 text-emerald-700' : ($aluno['status'] == 'Inativo' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'); ?>">
                    <?php echo $aluno['status']; ?>
                </span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Ultimos Atestados -->
    <div class="lg:col-span-3 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
        <div class="p-5 border-b border-slate-200 dark:border-slate-700">
            <h3 class="font-bold flex items-center gap-2"><i class="fas fa-file-medical text-violet-500"></i> Ultimos Atestados Enviados</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="bg-slate-50 dark:bg-slate-700/50 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                        <th class="px-5 py-3">Aluno</th>
                        <th class="px-5 py-3">Data</th>
                        <th class="px-5 py-3">Dias</th>
                        <th class="px-5 py-3">Motivo</th>
                        <th class="px-5 py-3 text-right">Arquivo</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                    <?php foreach ($ultimos_atestados as $at): ?>
                    <tr class="table-row">
                        <td class="px-5 py-3 font-medium"><?php echo htmlspecialchars($at['aluno_nome']); ?></td>
                        <td class="px-5 py-3 text-sm"><?php echo date('d/m/Y', strtotime($at['data'])); ?></td>
                        <td class="px-5 py-3 text-sm"><?php echo $at['dias']; ?> dia(s)</td>
                        <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($at['motivo']); ?></td>
                        <td class="px-5 py-3 text-right">
                            <?php if ($at['arquivo']): ?>
                            <a href="uploads/<?php echo htmlspecialchars($at['arquivo']); ?>" target="_blank" class="text-primary-600 hover:text-primary-700"><i class="fas fa-download"></i></a>
                            <?php else: ?>
                            <span class="text-slate-400">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
