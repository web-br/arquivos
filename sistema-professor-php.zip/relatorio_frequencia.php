<?php
require_once 'config.php';
requireLogin();

$aluno_id = $_GET['aluno_id'] ?? '';
if (!$aluno_id) { echo "Aluno nao informado"; exit; }

$frequencias = $pdo->prepare("SELECT f.*, a.nome as aluno_nome FROM frequencia f JOIN alunos a ON f.aluno_id = a.id WHERE f.aluno_id = ? ORDER BY f.data DESC");
$frequencias->execute([$aluno_id]);
$frequencias = $frequencias->fetchAll();

$stats = $pdo->prepare("SELECT COUNT(CASE WHEN presenca = 'Presente' THEN 1 END) as presentes, COUNT(CASE WHEN presenca = 'Falta' THEN 1 END) as faltas, COUNT(CASE WHEN presenca = 'Falta Justificada' THEN 1 END) as faltas_justificadas, COUNT(*) as total FROM frequencia WHERE aluno_id = ?");
$stats->execute([$aluno_id]);
$stats = $stats->fetch();

$percentual = $stats['total'] > 0 ? ($stats['presentes'] / $stats['total']) * 100 : 0;
$aluno = $pdo->query("SELECT nome FROM alunos WHERE id = $aluno_id")->fetch();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatorio de Frequencia</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>@media print { .no-print { display: none !important; } body { background: white; } }</style>
</head>
<body class="bg-white p-8">
    <div class="max-w-4xl mx-auto">
        <div class="flex items-center justify-between mb-6 no-print">
            <button onclick="window.print()" class="bg-emerald-500 text-white px-4 py-2 rounded-lg hover:bg-emerald-600"><i class="fas fa-print mr-2"></i>Imprimir / PDF</button>
            <button onclick="window.close()" class="bg-slate-500 text-white px-4 py-2 rounded-lg hover:bg-slate-600"><i class="fas fa-times mr-2"></i>Fechar</button>
        </div>

        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold">Relatorio de Frequencia</h1>
            <p class="text-lg font-medium text-slate-700"><?php echo htmlspecialchars($aluno['nome']); ?></p>
            <p class="text-sm text-slate-400">Gerado em: <?php echo date('d/m/Y H:i'); ?></p>
        </div>

        <div class="grid grid-cols-4 gap-4 mb-6">
            <div class="bg-emerald-50 p-4 rounded-xl text-center">
                <p class="text-2xl font-bold text-emerald-600"><?php echo $stats['presentes']; ?></p>
                <p class="text-sm text-emerald-700">Presentes</p>
            </div>
            <div class="bg-rose-50 p-4 rounded-xl text-center">
                <p class="text-2xl font-bold text-rose-600"><?php echo $stats['faltas']; ?></p>
                <p class="text-sm text-rose-700">Faltas</p>
            </div>
            <div class="bg-amber-50 p-4 rounded-xl text-center">
                <p class="text-2xl font-bold text-amber-600"><?php echo $stats['faltas_justificadas']; ?></p>
                <p class="text-sm text-amber-700">Justificadas</p>
            </div>
            <div class="bg-primary-50 p-4 rounded-xl text-center">
                <p class="text-2xl font-bold text-primary-600"><?php echo number_format($percentual, 1); ?>%</p>
                <p class="text-sm text-primary-700">Frequencia</p>
            </div>
        </div>

        <table class="w-full border-collapse">
            <thead>
                <tr class="bg-emerald-50 text-left">
                    <th class="border border-slate-300 px-3 py-2 text-sm">Data</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Presenca</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($frequencias as $f): ?>
                <tr>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo date('d/m/Y', strtotime($f['data'])); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm">
                        <span class="px-2 py-1 rounded text-xs <?php echo $f['presenca'] == 'Presente' ? 'bg-emerald-100 text-emerald-700' : ($f['presenca'] == 'Falta' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'); ?>">
                            <?php echo $f['presenca']; ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p class="mt-4 text-sm text-slate-500">Total de registros: <?php echo count($frequencias); ?></p>
    </div>
</body>
</html>
