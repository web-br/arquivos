<?php
require_once 'config.php';
requireLogin();

$aluno_id = $_GET['aluno_id'] ?? '';
if (!$aluno_id) { echo "Aluno nao informado"; exit; }

$notas = $pdo->prepare("SELECT n.*, a.nome as aluno_nome, t.nome as turma_nome FROM notas n JOIN alunos a ON n.aluno_id = a.id LEFT JOIN turmas t ON a.turma_id = t.id WHERE n.aluno_id = ? ORDER BY n.disciplina, n.bimestre");
$notas->execute([$aluno_id]);
$notas = $notas->fetchAll();

$medias = $pdo->prepare("SELECT disciplina, AVG(nota) as media FROM notas WHERE aluno_id = ? GROUP BY disciplina");
$medias->execute([$aluno_id]);
$medias = $medias->fetchAll();

$media_final = $pdo->prepare("SELECT AVG(nota) as media_final FROM notas WHERE aluno_id = ?");
$media_final->execute([$aluno_id]);
$media_final = $media_final->fetchColumn() ?: 0;

$situacao = $media_final >= 7 ? 'Aprovado' : ($media_final >= 5 ? 'Recuperacao' : 'Reprovado');

$aluno = $pdo->query("SELECT nome FROM alunos WHERE id = $aluno_id")->fetch();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatorio de Notas</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>@media print { .no-print { display: none !important; } body { background: white; } }</style>
</head>
<body class="bg-white p-8">
    <div class="max-w-4xl mx-auto">
        <div class="flex items-center justify-between mb-6 no-print">
            <button onclick="window.print()" class="bg-amber-500 text-white px-4 py-2 rounded-lg hover:bg-amber-600"><i class="fas fa-print mr-2"></i>Imprimir / PDF</button>
            <button onclick="window.close()" class="bg-slate-500 text-white px-4 py-2 rounded-lg hover:bg-slate-600"><i class="fas fa-times mr-2"></i>Fechar</button>
        </div>

        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold">Relatorio de Notas</h1>
            <p class="text-lg font-medium text-slate-700"><?php echo htmlspecialchars($aluno['nome']); ?></p>
            <p class="text-sm text-slate-400">Gerado em: <?php echo date('d/m/Y H:i'); ?></p>
        </div>

        <table class="w-full border-collapse mb-6">
            <thead>
                <tr class="bg-amber-50 text-left">
                    <th class="border border-slate-300 px-3 py-2 text-sm">Disciplina</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">1o Bim</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">2o Bim</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">3o Bim</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">4o Bim</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Media</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $disciplinas = [];
                foreach ($notas as $n) {
                    $disciplinas[$n['disciplina']][$n['bimestre']] = $n['nota'];
                }
                foreach ($disciplinas as $disc => $bimestres):
                    $media = array_sum($bimestres) / count($bimestres);
                ?>
                <tr>
                    <td class="border border-slate-300 px-3 py-2 text-sm font-medium"><?php echo htmlspecialchars($disc); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo isset($bimestres[1]) ? number_format($bimestres[1], 1) : '-'; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo isset($bimestres[2]) ? number_format($bimestres[2], 1) : '-'; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo isset($bimestres[3]) ? number_format($bimestres[3], 1) : '-'; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo isset($bimestres[4]) ? number_format($bimestres[4], 1) : '-'; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm font-bold"><?php echo number_format($media, 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="flex items-center justify-between bg-slate-50 p-4 rounded-xl">
            <div>
                <p class="text-sm text-slate-500">Media Final</p>
                <p class="text-2xl font-bold <?php echo $situacao == 'Aprovado' ? 'text-emerald-600' : ($situacao == 'Recuperacao' ? 'text-amber-600' : 'text-rose-600'); ?>"><?php echo number_format($media_final, 2); ?></p>
            </div>
            <div class="text-right">
                <p class="text-sm text-slate-500">Situacao</p>
                <span class="inline-flex px-4 py-2 rounded-lg text-sm font-bold <?php echo $situacao == 'Aprovado' ? 'bg-emerald-100 text-emerald-700' : ($situacao == 'Recuperacao' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'); ?>"><?php echo $situacao; ?></span>
            </div>
        </div>
    </div>
</body>
</html>
