<?php
require_once 'config.php';
requireLogin();

$aluno_id = $_GET['aluno_id'] ?? '';
if (!$aluno_id) { echo "Aluno nao informado"; exit; }

$atestados = $pdo->prepare("SELECT at.*, a.nome as aluno_nome FROM atestados at JOIN alunos a ON at.aluno_id = a.id WHERE at.aluno_id = ? ORDER BY at.data DESC");
$atestados->execute([$aluno_id]);
$atestados = $atestados->fetchAll();

$aluno = $pdo->query("SELECT nome FROM alunos WHERE id = $aluno_id")->fetch();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatorio de Atestados</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>@media print { .no-print { display: none !important; } body { background: white; } }</style>
</head>
<body class="bg-white p-8">
    <div class="max-w-4xl mx-auto">
        <div class="flex items-center justify-between mb-6 no-print">
            <button onclick="window.print()" class="bg-violet-500 text-white px-4 py-2 rounded-lg hover:bg-violet-600"><i class="fas fa-print mr-2"></i>Imprimir / PDF</button>
            <button onclick="window.close()" class="bg-slate-500 text-white px-4 py-2 rounded-lg hover:bg-slate-600"><i class="fas fa-times mr-2"></i>Fechar</button>
        </div>

        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold">Relatorio de Atestados</h1>
            <p class="text-lg font-medium text-slate-700"><?php echo htmlspecialchars($aluno['nome']); ?></p>
            <p class="text-sm text-slate-400">Gerado em: <?php echo date('d/m/Y H:i'); ?></p>
        </div>

        <table class="w-full border-collapse">
            <thead>
                <tr class="bg-violet-50 text-left">
                    <th class="border border-slate-300 px-3 py-2 text-sm">#</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Data</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Dias</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Motivo</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Observacoes</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Arquivo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($atestados as $i => $at): ?>
                <tr>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo $i + 1; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo date('d/m/Y', strtotime($at['data'])); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo $at['dias']; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo htmlspecialchars($at['motivo']); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo htmlspecialchars($at['observacoes'] ?: '-'); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm">
                        <?php if ($at['arquivo']): ?>
                        <span class="text-violet-600"><i class="fas fa-check"></i> Sim</span>
                        <?php else: ?>
                        <span class="text-slate-400">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p class="mt-4 text-sm text-slate-500">Total de atestados: <?php echo count($atestados); ?></p>
    </div>
</body>
</html>
