# Sistema Escolar - Professora

Sistema web simples e moderno para controle de alunos, turmas, notas, frequencia e atestados.

## Requisitos
- PHP 7.4+ com extensao pdo_sqlite habilitada
- Servidor web (Apache, Nginx, etc.)

## Instalacao
1. Extraia os arquivos para uma pasta no servidor web
2. Certifique-se de que a pasta `uploads/` tem permissao de escrita (chmod 755 ou 777)
3. Acesse pelo navegador: `http://localhost/sistema_professora/`
4. Login padrao: usuario `professora` / senha `senha123`

## Funcionalidades
- Dashboard com estatisticas
- Cadastro de Turmas (CRUD completo)
- Cadastro de Alunos (CRUD com pesquisa)
- Registro de Notas (com media automatica e situacao)
- Controle de Frequencia (Presente/Falta/Falta Justificada)
- Atestados (upload de PDF/JPG/PNG)
- Relatorios (impressao e PDF)
- Modo Claro/Escuro
- Interface responsiva (desktop, tablet, mobile)

## Seguranca
- Hash SHA-256 para senhas
- Prepared Statements contra SQL Injection
- Validacao de uploads de arquivos
- Controle de sessao
- Protecao de arquivos de banco de dados

## Banco de Dados
SQLite auto-criado na primeira execucao (`escola.db`)
