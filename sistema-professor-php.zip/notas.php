<?php
require_once 'config.php';
requireLogin();

// Criar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'criar') {
    $stmt = $pdo->prepare("INSERT INTO notas (aluno_id, disciplina, bimestre, nota, observacao) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['aluno_id'], $_POST['disciplina'], $_POST['bimestre'], $_POST['nota'], $_POST['observacao'] ?? '']);
    flashMessage('success', 'Nota registrada com sucesso!');
    header('Location: notas.php');
    exit;
}

// Editar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'editar') {
    $stmt = $pdo->prepare("UPDATE notas SET aluno_id=?, disciplina=?, bimestre=?, nota=?, observacao=? WHERE id=?");
    $stmt->execute([$_POST['aluno_id'], $_POST['disciplina'], $_POST['bimestre'], $_POST['nota'], $_POST['observacao'] ?? '', $_POST['id']]);
    flashMessage('success', 'Nota atualizada com sucesso!');
    header('Location: notas.php');
    exit;
}

// Excluir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'excluir') {
    $stmt = $pdo->prepare("DELETE FROM notas WHERE id = ?");
    $stmt->execute([$_POST['id']]);
    flashMessage('success', 'Nota excluida com sucesso!');
    header('Location: notas.php');
    exit;
}

// Listar notas
$notas = $pdo->query("
    SELECT n.*, a.nome as aluno_nome, t.nome as turma_nome
    FROM notas n
    JOIN alunos a ON n.aluno_id = a.id
    LEFT JOIN turmas t ON a.turma_id = t.id
    ORDER BY a.nome, n.disciplina, n.bimestre
")->fetchAll();

$alunos = $pdo->query("SELECT id, nome FROM alunos WHERE status = 'Ativo' ORDER BY nome")->fetchAll();
$turmas = $pdo->query("SELECT * FROM turmas ORDER BY nome")->fetchAll();

include 'header.php';
?>

<div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
    <div class="relative flex-1 max-w-md">
        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input type="text" id="search-notas" placeholder="Pesquisar notas..." onkeyup="filtrarNotas()"
            class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none">
    </div>
    <button onclick="openModal('modal-criar')" class="btn-primary flex items-center gap-2">
        <i class="fas fa-plus"></i> Nova Nota
    </button>
</div>

<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full" id="tabela-notas">
            <thead>
                <tr class="bg-slate-50 dark:bg-slate-700/50 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                    <th class="px-5 py-3">Aluno</th>
                    <th class="px-5 py-3">Turma</th>
                    <th class="px-5 py-3">Disciplina</th>
                    <th class="px-5 py-3">Bimestre</th>
                    <th class="px-5 py-3">Nota</th>
                    <th class="px-5 py-3">Situacao</th>
                    <th class="px-5 py-3 text-right">Acoes</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                <?php if (empty($notas)): ?>
                <tr><td colspan="7" class="px-5 py-8 text-center text-slate-400">Nenhuma nota registrada</td></tr>
                <?php else: foreach ($notas as $n): 
                    $situacao = $n['nota'] >= 7 ? 'Aprovado' : ($n['nota'] >= 5 ? 'Recuperacao' : 'Reprovado');
                ?>
                <tr class="table-row" data-search="<?php echo strtolower($n['aluno_nome'] . ' ' . $n['disciplina']); ?>">
                    <td class="px-5 py-3 font-medium"><?php echo htmlspecialchars($n['aluno_nome']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($n['turma_nome'] ?? '-'); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($n['disciplina']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo $n['bimestre']; ?>o Bimestre</td>
                    <td class="px-5 py-3 font-bold"><?php echo number_format($n['nota'], 1); ?></td>
                    <td class="px-5 py-3">
                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium
                            <?php echo $situacao == 'Aprovado' ? 'bg-emerald-100 text-emerald-700' : ($situacao == 'Recuperacao' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'); ?>">
                            <?php echo $situacao; ?>
                        </span>
                    </td>
                    <td class="px-5 py-3 text-right space-x-2">
                        <button onclick="editarNota(<?php echo $n['id']; ?>)" class="text-primary-600 hover:text-primary-700 p-1"><i class="fas fa-edit"></i></button>
                        <button onclick="confirmDelete('Tem certeza que deseja excluir esta nota?', 'form-excluir-<?php echo $n['id']; ?>')" class="text-rose-600 hover:text-rose-700 p-1"><i class="fas fa-trash"></i></button>
                        <form id="form-excluir-<?php echo $n['id']; ?>" method="POST" class="hidden">
                            <input type="hidden" name="acao" value="excluir">
                            <input type="hidden" name="id" value="<?php echo $n['id']; ?>">
                        </form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Criar -->
<div id="modal-criar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Nova Nota</h3>
            <button onclick="closeModal('modal-criar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="acao" value="criar">
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Aluno</label>
                <select name="aluno_id" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <option value="">Selecione...</option>
                    <?php foreach ($alunos as $a): ?>
                    <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['nome']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Disciplina</label>
                    <input type="text" name="disciplina" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Bimestre</label>
                    <select name="bimestre" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                        <option value="1">1o Bimestre</option>
                        <option value="2">2o Bimestre</option>
                        <option value="3">3o Bimestre</option>
                        <option value="4">4o Bimestre</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nota (0 a 10)</label>
                <input type="number" name="nota" step="0.1" min="0" max="10" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacao</label>
                <textarea name="observacao" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-criar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Salvar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Editar -->
<div id="modal-editar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Editar Nota</h3>
            <button onclick="closeModal('modal-editar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" class="space-y-4" id="form-editar">
            <input type="hidden" name="acao" value="editar">
            <input type="hidden" name="id" id="edit-id">
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Aluno</label>
                <select name="aluno_id" id="edit-aluno" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <?php foreach ($alunos as $a): ?>
                    <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['nome']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Disciplina</label>
                    <input type="text" name="disciplina" id="edit-disciplina" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Bimestre</label>
                    <select name="bimestre" id="edit-bimestre" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                        <option value="1">1o Bimestre</option>
                        <option value="2">2o Bimestre</option>
                        <option value="3">3o Bimestre</option>
                        <option value="4">4o Bimestre</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nota (0 a 10)</label>
                <input type="number" name="nota" id="edit-nota" step="0.1" min="0" max="10" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacao</label>
                <textarea name="observacao" id="edit-obs" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-editar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Atualizar</button>
            </div>
        </form>
    </div>
</div>

<script>
const notasData = <?php echo json_encode($notas); ?>;
function editarNota(id) {
    const n = notasData.find(x => x.id == id);
    if (n) {
        document.getElementById('edit-id').value = n.id;
        document.getElementById('edit-aluno').value = n.aluno_id;
        document.getElementById('edit-disciplina').value = n.disciplina;
        document.getElementById('edit-bimestre').value = n.bimestre;
        document.getElementById('edit-nota').value = n.nota;
        document.getElementById('edit-obs').value = n.observacao || '';
        openModal('modal-editar');
    }
}

function filtrarNotas() {
    const termo = document.getElementById('search-notas').value.toLowerCase();
    const rows = document.querySelectorAll('#tabela-notas tbody tr');
    rows.forEach(row => {
        const search = row.getAttribute('data-search');
        if (search && search.includes(termo)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>

<?php include 'footer.php'; ?>
