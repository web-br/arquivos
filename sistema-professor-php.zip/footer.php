<?php if (isLoggedIn()): ?>
        </main>
    </div>

    <script>
        // Dark mode
        function toggleDarkMode() {
            const html = document.documentElement;
            if (html.classList.contains('dark')) {
                html.classList.remove('dark');
                html.classList.add('light');
                localStorage.setItem('theme', 'light');
            } else {
                html.classList.remove('light');
                html.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            }
        }

        // Load saved theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.documentElement.classList.remove('light');
            document.documentElement.classList.add('dark');
        }

        // Sidebar toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('mobile-overlay');
            sidebar.classList.toggle('sidebar-closed');
            overlay.classList.toggle('hidden');
        }

        // Modal functions
        function openModal(id) {
            document.getElementById(id).classList.add('active');
        }
        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
        }

        // Confirm delete
        function confirmDelete(message, formId) {
            if (confirm(message)) {
                document.getElementById(formId).submit();
            }
        }

        // Auto-hide flash messages
        setTimeout(() => {
            const flashes = document.querySelectorAll('.fade-in');
            flashes.forEach(f => f.style.opacity = '0');
        }, 4000);
    </script>
<?php endif; ?>
</body>
</html>
