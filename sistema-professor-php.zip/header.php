<?php
require_once 'config.php';
$flash = showFlash();
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="pt-BR" class="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Escolar - Professora</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: { 50: '#eff6ff', 100: '#dbeafe', 200: '#bfdbfe', 300: '#93c5fd', 400: '#60a5fa', 500: '#3b82f6', 600: '#2563eb', 700: '#1d4ed8', 800: '#1e40af', 900: '#1e3a8a' },
                        emerald: { 50: '#ecfdf5', 100: '#d1fae5', 200: '#a7f3d0', 300: '#6ee7b7', 400: '#34d399', 500: '#10b981', 600: '#059669', 700: '#047857', 800: '#065f46', 900: '#064e3b' },
                        amber: { 50: '#fffbeb', 100: '#fef3c7', 200: '#fde68a', 300: '#fcd34d', 400: '#fbbf24', 500: '#f59e0b', 600: '#d97706', 700: '#b45309', 800: '#92400e', 900: '#78350f' },
                        rose: { 50: '#fff1f2', 100: '#ffe4e6', 200: '#fecdd3', 300: '#fda4af', 400: '#fb7185', 500: '#f43f5e', 600: '#e11d48', 700: '#be123c', 800: '#9f1239', 900: '#881337' },
                        slate: { 50: '#f8fafc', 100: '#f1f5f9', 200: '#e2e8f0', 300: '#cbd5e1', 400: '#94a3b8', 500: '#64748b', 600: '#475569', 700: '#334155', 800: '#1e293b', 900: '#0f172a' },
                    }
                }
            }
        }
    </script>
    <style>
        .sidebar { transition: transform 0.3s ease; }
        .sidebar-closed { transform: translateX(-100%); }
        .fade-in { animation: fadeIn 0.3s ease-in; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .card-hover { transition: all 0.2s ease; }
        .card-hover:hover { transform: translateY(-2px); box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); }
        .btn-primary { @apply bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition-colors; }
        .btn-danger { @apply bg-rose-500 hover:bg-rose-600 text-white px-4 py-2 rounded-lg transition-colors; }
        .btn-success { @apply bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg transition-colors; }
        .btn-amber { @apply bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-lg transition-colors; }
        .table-row:hover { @apply bg-slate-50 dark:bg-slate-800; }
        .modal { display: none; position: fixed; inset: 0; z-index: 50; background: rgba(0,0,0,0.5); align-items: center; justify-content: center; }
        .modal.active { display: flex; }
        .modal-content { animation: modalSlide 0.2s ease; }
        @keyframes modalSlide { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        /* Scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        .dark ::-webkit-scrollbar-thumb { background: #475569; }
        .dark ::-webkit-scrollbar-thumb:hover { background: #64748b; }
    </style>
</head>
<body class="bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 transition-colors duration-200">
    <?php if (isLoggedIn()): ?>
    <!-- Mobile overlay -->
    <div id="mobile-overlay" class="fixed inset-0 bg-black/50 z-30 hidden lg:hidden" onclick="toggleSidebar()"></div>

    <!-- Sidebar -->
    <aside id="sidebar" class="sidebar fixed top-0 left-0 h-full w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 z-40 flex flex-col sidebar-closed lg:sidebar-closed lg:translate-x-0">
        <!-- Logo -->
        <div class="p-6 border-b border-slate-200 dark:border-slate-700">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center text-white">
                    <i class="fas fa-graduation-cap text-lg"></i>
                </div>
                <div>
                    <h1 class="font-bold text-lg leading-tight">Escola</h1>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Sistema da Professora</p>
                </div>
            </div>
        </div>

        <!-- Menu -->
        <nav class="flex-1 overflow-y-auto p-4 space-y-1">
            <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors <?php echo $current_page == 'dashboard' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50'; ?>">
                <i class="fas fa-chart-pie w-5 text-center"></i>
                <span>Dashboard</span>
            </a>
            <a href="turmas.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors <?php echo $current_page == 'turmas' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50'; ?>">
                <i class="fas fa-chalkboard w-5 text-center"></i>
                <span>Turmas</span>
            </a>
            <a href="alunos.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors <?php echo $current_page == 'alunos' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50'; ?>">
                <i class="fas fa-users w-5 text-center"></i>
                <span>Alunos</span>
            </a>
            <a href="notas.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors <?php echo $current_page == 'notas' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50'; ?>">
                <i class="fas fa-star w-5 text-center"></i>
                <span>Notas</span>
            </a>
            <a href="frequencia.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors <?php echo $current_page == 'frequencia' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50'; ?>">
                <i class="fas fa-clipboard-check w-5 text-center"></i>
                <span>Frequencia</span>
            </a>
            <a href="atestados.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors <?php echo $current_page == 'atestados' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50'; ?>">
                <i class="fas fa-file-medical w-5 text-center"></i>
                <span>Atestados</span>
            </a>
            <a href="relatorios.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors <?php echo $current_page == 'relatorios' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50'; ?>">
                <i class="fas fa-file-pdf w-5 text-center"></i>
                <span>Relatorios</span>
            </a>
        </nav>

        <!-- Bottom -->
        <div class="p-4 border-t border-slate-200 dark:border-slate-700 space-y-2">
            <a href="alterar_senha.php" class="flex items-center gap-3 px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-colors">
                <i class="fas fa-key w-5 text-center"></i>
                <span>Alterar Senha</span>
            </a>
            <a href="logout.php" class="flex items-center gap-3 px-4 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors">
                <i class="fas fa-sign-out-alt w-5 text-center"></i>
                <span>Sair</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="lg:ml-64 min-h-screen">
        <!-- Top Bar -->
        <header class="sticky top-0 z-20 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 px-4 py-3 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebar()" class="lg:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
                    <i class="fas fa-bars"></i>
                </button>
                <h2 class="font-semibold text-lg capitalize"><?php echo str_replace('_', ' ', $current_page); ?></h2>
            </div>
            <div class="flex items-center gap-3">
                <button onclick="toggleDarkMode()" class="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors" title="Alternar tema">
                    <i class="fas fa-moon dark:hidden"></i>
                    <i class="fas fa-sun hidden dark:inline"></i>
                </button>
                <div class="flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-700 rounded-lg">
                    <i class="fas fa-user-circle text-slate-400"></i>
                    <span class="text-sm font-medium"><?php echo htmlspecialchars($_SESSION['usuario'] ?? 'Professora'); ?></span>
                </div>
            </div>
        </header>

        <!-- Flash Messages -->
        <?php if ($flash): ?>
        <div class="mx-4 mt-4">
            <div class="fade-in px-4 py-3 rounded-xl flex items-center gap-3 <?php echo $flash['tipo'] == 'success' ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800' : 'bg-rose-50 dark:bg-rose-900/20 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'; ?>">
                <i class="fas fa-<?php echo $flash['tipo'] == 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                <span><?php echo htmlspecialchars($flash['mensagem']); ?></span>
                <button onclick="this.parentElement.remove()" class="ml-auto hover:opacity-70"><i class="fas fa-times"></i></button>
            </div>
        </div>
        <?php endif; ?>

        <!-- Page Content -->
        <main class="p-4 lg:p-6">
    <?php endif; ?>
