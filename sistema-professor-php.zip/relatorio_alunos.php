<?php
require_once 'config.php';
requireLogin();

$turma_id = $_GET['turma_id'] ?? '';
$status = $_GET['status'] ?? '';

$query = "SELECT a.*, t.nome as turma_nome FROM alunos a LEFT JOIN turmas t ON a.turma_id = t.id WHERE 1=1";
$params = [];
if ($turma_id) { $query .= " AND a.turma_id = ?"; $params[] = $turma_id; }
if ($status) { $query .= " AND a.status = ?"; $params[] = $status; }
$query .= " ORDER BY a.nome";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$alunos = $stmt->fetchAll();

$turma_info = $turma_id ? $pdo->query("SELECT * FROM turmas WHERE id = $turma_id")->fetch() : ['nome' => 'Todas as Turmas'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatorio de Alunos</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @media print { .no-print { display: none !important; } body { background: white; } }
    </style>
</head>
<body class="bg-white p-8">
    <div class="max-w-4xl mx-auto">
        <div class="flex items-center justify-between mb-6 no-print">
            <button onclick="window.print()" class="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700">
                <i class="fas fa-print mr-2"></i>Imprimir / PDF
            </button>
            <button onclick="window.close()" class="bg-slate-500 text-white px-4 py-2 rounded-lg hover:bg-slate-600">
                <i class="fas fa-times mr-2"></i>Fechar
            </button>
        </div>

        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold">Relatorio de Alunos</h1>
            <p class="text-slate-500">Turma: <?php echo htmlspecialchars($turma_info['nome']); ?> | Status: <?php echo $status ?: 'Todos'; ?></p>
            <p class="text-sm text-slate-400">Gerado em: <?php echo date('d/m/Y H:i'); ?></p>
        </div>

        <table class="w-full border-collapse">
            <thead>
                <tr class="bg-slate-100 text-left">
                    <th class="border border-slate-300 px-3 py-2 text-sm">#</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Nome</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Turma</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Serie</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Ano</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Turno</th>
                    <th class="border border-slate-300 px-3 py-2 text-sm">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alunos as $i => $a): ?>
                <tr>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo $i + 1; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm font-medium"><?php echo htmlspecialchars($a['nome']); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo htmlspecialchars($a['turma_nome'] ?? '-'); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo htmlspecialchars($a['serie']); ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo $a['ano_letivo']; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm"><?php echo $a['turno']; ?></td>
                    <td class="border border-slate-300 px-3 py-2 text-sm">
                        <span class="px-2 py-1 rounded text-xs <?php echo $a['status'] == 'Ativo' ? 'bg-emerald-100 text-emerald-700' : ($a['status'] == 'Inativo' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'); ?>">
                            <?php echo $a['status']; ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p class="mt-4 text-sm text-slate-500">Total de alunos: <?php echo count($alunos); ?></p>
    </div>
</body>
</html>
