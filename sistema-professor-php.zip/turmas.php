<?php
require_once 'config.php';
requireLogin();

// Criar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'criar') {
    $stmt = $pdo->prepare("INSERT INTO turmas (nome, serie, ano_letivo, grau, turno, observacoes) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['nome'], $_POST['serie'], $_POST['ano_letivo'], $_POST['grau'], $_POST['turno'], $_POST['observacoes'] ?? '']);
    flashMessage('success', 'Turma criada com sucesso!');
    header('Location: turmas.php');
    exit;
}

// Editar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'editar') {
    $stmt = $pdo->prepare("UPDATE turmas SET nome=?, serie=?, ano_letivo=?, grau=?, turno=?, observacoes=? WHERE id=?");
    $stmt->execute([$_POST['nome'], $_POST['serie'], $_POST['ano_letivo'], $_POST['grau'], $_POST['turno'], $_POST['observacoes'] ?? '', $_POST['id']]);
    flashMessage('success', 'Turma atualizada com sucesso!');
    header('Location: turmas.php');
    exit;
}

// Excluir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'excluir') {
    $stmt = $pdo->prepare("DELETE FROM turmas WHERE id = ?");
    $stmt->execute([$_POST['id']]);
    flashMessage('success', 'Turma excluida com sucesso!');
    header('Location: turmas.php');
    exit;
}

// Buscar
$search = $_GET['q'] ?? '';
if ($search) {
    $stmt = $pdo->prepare("SELECT * FROM turmas WHERE nome LIKE ? OR serie LIKE ? ORDER BY nome");
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query("SELECT * FROM turmas ORDER BY nome");
}
$turmas = $stmt->fetchAll();

include 'header.php';
?>

<div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
    <div class="relative flex-1 max-w-md">
        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <form method="GET">
            <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Pesquisar turmas..."
                class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none">
        </form>
    </div>
    <button onclick="openModal('modal-criar')" class="btn-primary flex items-center gap-2">
        <i class="fas fa-plus"></i> Nova Turma
    </button>
</div>

<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead>
                <tr class="bg-slate-50 dark:bg-slate-700/50 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                    <th class="px-5 py-3">Nome</th>
                    <th class="px-5 py-3">Serie</th>
                    <th class="px-5 py-3">Ano</th>
                    <th class="px-5 py-3">Grau</th>
                    <th class="px-5 py-3">Turno</th>
                    <th class="px-5 py-3">Observacoes</th>
                    <th class="px-5 py-3 text-right">Acoes</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                <?php if (empty($turmas)): ?>
                <tr><td colspan="7" class="px-5 py-8 text-center text-slate-400">Nenhuma turma cadastrada</td></tr>
                <?php else: foreach ($turmas as $t): ?>
                <tr class="table-row">
                    <td class="px-5 py-3 font-medium"><?php echo htmlspecialchars($t['nome']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($t['serie']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo $t['ano_letivo']; ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($t['grau']); ?></td>
                    <td class="px-5 py-3">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                            <?php echo $t['turno'] == 'Manha' ? 'bg-amber-100 text-amber-700' : ($t['turno'] == 'Tarde' ? 'bg-orange-100 text-orange-700' : 'bg-indigo-100 text-indigo-700'); ?>">
                            <?php echo $t['turno']; ?>
                        </span>
                    </td>
                    <td class="px-5 py-3 text-sm text-slate-500"><?php echo htmlspecialchars($t['observacoes'] ?: '-'); ?></td>
                    <td class="px-5 py-3 text-right space-x-2">
                        <button onclick="editarTurma(<?php echo $t['id']; ?>)" class="text-primary-600 hover:text-primary-700 p-1"><i class="fas fa-edit"></i></button>
                        <button onclick="confirmDelete('Tem certeza que deseja excluir esta turma?', 'form-excluir-<?php echo $t['id']; ?>')" class="text-rose-600 hover:text-rose-700 p-1"><i class="fas fa-trash"></i></button>
                        <form id="form-excluir-<?php echo $t['id']; ?>" method="POST" class="hidden">
                            <input type="hidden" name="acao" value="excluir">
                            <input type="hidden" name="id" value="<?php echo $t['id']; ?>">
                        </form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Criar -->
<div id="modal-criar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Nova Turma</h3>
            <button onclick="closeModal('modal-criar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="acao" value="criar">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nome</label>
                    <input type="text" name="nome" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Serie</label>
                    <input type="text" name="serie" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Ano Letivo</label>
                    <input type="number" name="ano_letivo" required value="<?php echo date('Y'); ?>" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Grau</label>
                    <select name="grau" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                        <option value="Fundamental">Fundamental</option>
                        <option value="Medio">Medio</option>
                        <option value="Superior">Superior</option>
                    </select>
                </div>
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Turno</label>
                    <select name="turno" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                        <option value="Manha">Manha</option>
                        <option value="Tarde">Tarde</option>
                        <option value="Noite">Noite</option>
                    </select>
                </div>
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacoes</label>
                    <textarea name="observacoes" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
                </div>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-criar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Salvar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Editar -->
<div id="modal-editar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Editar Turma</h3>
            <button onclick="closeModal('modal-editar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" class="space-y-4" id="form-editar">
            <input type="hidden" name="acao" value="editar">
            <input type="hidden" name="id" id="edit-id">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nome</label>
                    <input type="text" name="nome" id="edit-nome" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Serie</label>
                    <input type="text" name="serie" id="edit-serie" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Ano Letivo</label>
                    <input type="number" name="ano_letivo" id="edit-ano" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Grau</label>
                    <select name="grau" id="edit-grau" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                        <option value="Fundamental">Fundamental</option>
                        <option value="Medio">Medio</option>
                        <option value="Superior">Superior</option>
                    </select>
                </div>
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Turno</label>
                    <select name="turno" id="edit-turno" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                        <option value="Manha">Manha</option>
                        <option value="Tarde">Tarde</option>
                        <option value="Noite">Noite</option>
                    </select>
                </div>
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacoes</label>
                    <textarea name="observacoes" id="edit-obs" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
                </div>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-editar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Atualizar</button>
            </div>
        </form>
    </div>
</div>

<script>
const turmasData = <?php echo json_encode($turmas); ?>;
function editarTurma(id) {
    const t = turmasData.find(x => x.id == id);
    if (t) {
        document.getElementById('edit-id').value = t.id;
        document.getElementById('edit-nome').value = t.nome;
        document.getElementById('edit-serie').value = t.serie;
        document.getElementById('edit-ano').value = t.ano_letivo;
        document.getElementById('edit-grau').value = t.grau;
        document.getElementById('edit-turno').value = t.turno;
        document.getElementById('edit-obs').value = t.observacoes || '';
        openModal('modal-editar');
    }
}
</script>

<?php include 'footer.php'; ?>
