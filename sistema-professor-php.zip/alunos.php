<?php
require_once 'config.php';
requireLogin();

// Criar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'criar') {
    $stmt = $pdo->prepare("SELECT serie, ano_letivo, turno FROM turmas WHERE id = ?");
    $stmt->execute([$_POST['turma_id']]);
    $turma = $stmt->fetch();

    $stmt = $pdo->prepare("INSERT INTO alunos (nome, turma_id, serie, ano_letivo, turno, status, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['nome'], $_POST['turma_id'], $turma['serie'], $turma['ano_letivo'], $turma['turno'], $_POST['status'], $_POST['observacoes'] ?? '']);
    flashMessage('success', 'Aluno cadastrado com sucesso!');
    header('Location: alunos.php');
    exit;
}

// Editar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'editar') {
    $stmt = $pdo->prepare("SELECT serie, ano_letivo, turno FROM turmas WHERE id = ?");
    $stmt->execute([$_POST['turma_id']]);
    $turma = $stmt->fetch();

    $stmt = $pdo->prepare("UPDATE alunos SET nome=?, turma_id=?, serie=?, ano_letivo=?, turno=?, status=?, observacoes=? WHERE id=?");
    $stmt->execute([$_POST['nome'], $_POST['turma_id'], $turma['serie'], $turma['ano_letivo'], $turma['turno'], $_POST['status'], $_POST['observacoes'] ?? '', $_POST['id']]);
    flashMessage('success', 'Aluno atualizado com sucesso!');
    header('Location: alunos.php');
    exit;
}

// Excluir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'excluir') {
    $stmt = $pdo->prepare("DELETE FROM alunos WHERE id = ?");
    $stmt->execute([$_POST['id']]);
    flashMessage('success', 'Aluno excluido com sucesso!');
    header('Location: alunos.php');
    exit;
}

// Buscar
$search = $_GET['q'] ?? '';
$status_filter = $_GET['status'] ?? '';

$query = "SELECT a.*, t.nome as turma_nome FROM alunos a LEFT JOIN turmas t ON a.turma_id = t.id WHERE 1=1";
$params = [];

if ($search) {
    $query .= " AND a.nome LIKE ?";
    $params[] = "%$search%";
}
if ($status_filter) {
    $query .= " AND a.status = ?";
    $params[] = $status_filter;
}
$query .= " ORDER BY a.nome";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$alunos = $stmt->fetchAll();

$turmas = $pdo->query("SELECT * FROM turmas ORDER BY nome")->fetchAll();

include 'header.php';
?>

<div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
    <div class="flex flex-col sm:flex-row gap-3 flex-1 max-w-2xl">
        <div class="relative flex-1">
            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <form method="GET" class="flex gap-2">
                <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Pesquisar por nome..."
                    class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none">
                <select name="status" onchange="this.form.submit()" class="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-primary-500">
                    <option value="">Todos</option>
                    <option value="Ativo" <?php echo $status_filter == 'Ativo' ? 'selected' : ''; ?>>Ativo</option>
                    <option value="Inativo" <?php echo $status_filter == 'Inativo' ? 'selected' : ''; ?>>Inativo</option>
                    <option value="Transferido" <?php echo $status_filter == 'Transferido' ? 'selected' : ''; ?>>Transferido</option>
                </select>
            </form>
        </div>
    </div>
    <button onclick="openModal('modal-criar')" class="btn-primary flex items-center gap-2">
        <i class="fas fa-plus"></i> Novo Aluno
    </button>
</div>

<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead>
                <tr class="bg-slate-50 dark:bg-slate-700/50 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                    <th class="px-5 py-3">Nome</th>
                    <th class="px-5 py-3">Turma</th>
                    <th class="px-5 py-3">Serie</th>
                    <th class="px-5 py-3">Ano</th>
                    <th class="px-5 py-3">Turno</th>
                    <th class="px-5 py-3">Status</th>
                    <th class="px-5 py-3 text-right">Acoes</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                <?php if (empty($alunos)): ?>
                <tr><td colspan="7" class="px-5 py-8 text-center text-slate-400">Nenhum aluno cadastrado</td></tr>
                <?php else: foreach ($alunos as $a): ?>
                <tr class="table-row">
                    <td class="px-5 py-3 font-medium"><?php echo htmlspecialchars($a['nome']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($a['turma_nome'] ?? '-'); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($a['serie']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo $a['ano_letivo']; ?></td>
                    <td class="px-5 py-3">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                            <?php echo $a['turno'] == 'Manha' ? 'bg-amber-100 text-amber-700' : ($a['turno'] == 'Tarde' ? 'bg-orange-100 text-orange-700' : 'bg-indigo-100 text-indigo-700'); ?>">
                            <?php echo $a['turno']; ?>
                        </span>
                    </td>
                    <td class="px-5 py-3">
                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium
                            <?php echo $a['status'] == 'Ativo' ? 'bg-emerald-100 text-emerald-700' : ($a['status'] == 'Inativo' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'); ?>">
                            <?php echo $a['status']; ?>
                        </span>
                    </td>
                    <td class="px-5 py-3 text-right space-x-2">
                        <button onclick="editarAluno(<?php echo $a['id']; ?>)" class="text-primary-600 hover:text-primary-700 p-1"><i class="fas fa-edit"></i></button>
                        <button onclick="confirmDelete('Tem certeza que deseja excluir este aluno?', 'form-excluir-<?php echo $a['id']; ?>')" class="text-rose-600 hover:text-rose-700 p-1"><i class="fas fa-trash"></i></button>
                        <form id="form-excluir-<?php echo $a['id']; ?>" method="POST" class="hidden">
                            <input type="hidden" name="acao" value="excluir">
                            <input type="hidden" name="id" value="<?php echo $a['id']; ?>">
                        </form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Criar -->
<div id="modal-criar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Novo Aluno</h3>
            <button onclick="closeModal('modal-criar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="acao" value="criar">
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nome Completo</label>
                <input type="text" name="nome" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Turma</label>
                <select name="turma_id" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <option value="">Selecione...</option>
                    <?php foreach ($turmas as $t): ?>
                    <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['nome']); ?> - <?php echo $t['serie']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status</label>
                <select name="status" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <option value="Ativo">Ativo</option>
                    <option value="Inativo">Inativo</option>
                    <option value="Transferido">Transferido</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacoes</label>
                <textarea name="observacoes" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-criar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Salvar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Editar -->
<div id="modal-editar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Editar Aluno</h3>
            <button onclick="closeModal('modal-editar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" class="space-y-4" id="form-editar">
            <input type="hidden" name="acao" value="editar">
            <input type="hidden" name="id" id="edit-id">
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nome Completo</label>
                <input type="text" name="nome" id="edit-nome" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Turma</label>
                <select name="turma_id" id="edit-turma" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <?php foreach ($turmas as $t): ?>
                    <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['nome']); ?> - <?php echo $t['serie']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status</label>
                <select name="status" id="edit-status" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <option value="Ativo">Ativo</option>
                    <option value="Inativo">Inativo</option>
                    <option value="Transferido">Transferido</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacoes</label>
                <textarea name="observacoes" id="edit-obs" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-editar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Atualizar</button>
            </div>
        </form>
    </div>
</div>

<script>
const alunosData = <?php echo json_encode($alunos); ?>;
function editarAluno(id) {
    const a = alunosData.find(x => x.id == id);
    if (a) {
        document.getElementById('edit-id').value = a.id;
        document.getElementById('edit-nome').value = a.nome;
        document.getElementById('edit-turma').value = a.turma_id;
        document.getElementById('edit-status').value = a.status;
        document.getElementById('edit-obs').value = a.observacoes || '';
        openModal('modal-editar');
    }
}
</script>

<?php include 'footer.php'; ?>
