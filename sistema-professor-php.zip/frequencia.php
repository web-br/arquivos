<?php
require_once 'config.php';
requireLogin();

$data = $_GET['data'] ?? date('Y-m-d');

// Registrar frequencia via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === '1') {
    $aluno_id = $_POST['aluno_id'];
    $presenca = $_POST['presenca'];

    $stmt = $pdo->prepare("SELECT id FROM frequencia WHERE aluno_id = ? AND data = ?");
    $stmt->execute([$aluno_id, $data]);
    $existing = $stmt->fetch();

    if ($existing) {
        $stmt = $pdo->prepare("UPDATE frequencia SET presenca = ? WHERE id = ?");
        $stmt->execute([$presenca, $existing['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO frequencia (aluno_id, data, presenca) VALUES (?, ?, ?)");
        $stmt->execute([$aluno_id, $data, $presenca]);
    }
    echo json_encode(['success' => true]);
    exit;
}

// Listar alunos com frequencia do dia
$stmt = $pdo->prepare("
    SELECT a.id, a.nome, a.status, t.nome as turma_nome, f.presenca, f.id as freq_id
    FROM alunos a
    LEFT JOIN turmas t ON a.turma_id = t.id
    LEFT JOIN frequencia f ON a.id = f.aluno_id AND f.data = ?
    WHERE a.status = 'Ativo'
    ORDER BY a.nome
");
$stmt->execute([$data]);
$alunos_freq = $stmt->fetchAll();

// Estatisticas do dia
$stmt = $pdo->prepare("
    SELECT 
        COUNT(CASE WHEN presenca = 'Presente' THEN 1 END) as presentes,
        COUNT(CASE WHEN presenca = 'Falta' THEN 1 END) as faltas,
        COUNT(CASE WHEN presenca = 'Falta Justificada' THEN 1 END) as faltas_justificadas
    FROM frequencia
    WHERE data = ?
");
$stmt->execute([$data]);
$stats = $stmt->fetch();

include 'header.php';
?>

<div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
    <form method="GET" class="flex items-center gap-3">
        <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Data:</label>
        <input type="date" name="data" value="<?php echo $data; ?>" onchange="this.form.submit()"
            class="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-primary-500">
    </form>
    <div class="flex gap-3">
        <div class="flex items-center gap-2 px-3 py-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg text-emerald-700 dark:text-emerald-300 text-sm">
            <i class="fas fa-check-circle"></i> <?php echo $stats['presentes'] ?? 0; ?> Presentes
        </div>
        <div class="flex items-center gap-2 px-3 py-2 bg-rose-50 dark:bg-rose-900/20 rounded-lg text-rose-700 dark:text-rose-300 text-sm">
            <i class="fas fa-times-circle"></i> <?php echo $stats['faltas'] ?? 0; ?> Faltas
        </div>
        <div class="flex items-center gap-2 px-3 py-2 bg-amber-50 dark:bg-amber-900/20 rounded-lg text-amber-700 dark:text-amber-300 text-sm">
            <i class="fas fa-file-medical"></i> <?php echo $stats['faltas_justificadas'] ?? 0; ?> Justificadas
        </div>
    </div>
</div>

<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead>
                <tr class="bg-slate-50 dark:bg-slate-700/50 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                    <th class="px-5 py-3">Aluno</th>
                    <th class="px-5 py-3">Turma</th>
                    <th class="px-5 py-3 text-center">Presenca</th>
                    <th class="px-5 py-3 text-center">Falta</th>
                    <th class="px-5 py-3 text-center">Falta Justificada</th>
                    <th class="px-5 py-3 text-center">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                <?php if (empty($alunos_freq)): ?>
                <tr><td colspan="6" class="px-5 py-8 text-center text-slate-400">Nenhum aluno ativo cadastrado</td></tr>
                <?php else: foreach ($alunos_freq as $a): 
                    $presente = $a['presenca'] === 'Presente';
                    $falta = $a['presenca'] === 'Falta';
                    $falta_just = $a['presenca'] === 'Falta Justificada';
                    $nao_registrado = !$a['presenca'];
                ?>
                <tr class="table-row <?php echo $nao_registrado ? 'bg-amber-50/50 dark:bg-amber-900/10' : ''; ?>">
                    <td class="px-5 py-3 font-medium"><?php echo htmlspecialchars($a['nome']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($a['turma_nome'] ?? '-'); ?></td>
                    <td class="px-5 py-3 text-center">
                        <button onclick="registrarFreq(<?php echo $a['id']; ?>, 'Presente')" 
                            class="w-10 h-10 rounded-xl transition-all <?php echo $presente ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-700 text-slate-400 hover:bg-emerald-100 hover:text-emerald-600'; ?>">
                            <i class="fas fa-check"></i>
                        </button>
                    </td>
                    <td class="px-5 py-3 text-center">
                        <button onclick="registrarFreq(<?php echo $a['id']; ?>, 'Falta')" 
                            class="w-10 h-10 rounded-xl transition-all <?php echo $falta ? 'bg-rose-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-700 text-slate-400 hover:bg-rose-100 hover:text-rose-600'; ?>">
                            <i class="fas fa-times"></i>
                        </button>
                    </td>
                    <td class="px-5 py-3 text-center">
                        <button onclick="registrarFreq(<?php echo $a['id']; ?>, 'Falta Justificada')" 
                            class="w-10 h-10 rounded-xl transition-all <?php echo $falta_just ? 'bg-amber-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-700 text-slate-400 hover:bg-amber-100 hover:text-amber-600'; ?>">
                            <i class="fas fa-file-medical"></i>
                        </button>
                    </td>
                    <td class="px-5 py-3 text-center">
                        <?php if ($nao_registrado): ?>
                            <span class="text-xs text-amber-600 font-medium">Nao registrado</span>
                        <?php else: ?>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium
                                <?php echo $presente ? 'bg-emerald-100 text-emerald-700' : ($falta ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'); ?>">
                                <?php echo $a['presenca']; ?>
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function registrarFreq(alunoId, presenca) {
    const formData = new FormData();
    formData.append('ajax', '1');
    formData.append('aluno_id', alunoId);
    formData.append('presenca', presenca);

    fetch('frequencia.php?data=<?php echo $data; ?>', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) location.reload();
    });
}
</script>

<?php include 'footer.php'; ?>
