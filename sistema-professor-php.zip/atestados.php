<?php
require_once 'config.php';
requireLogin();

// Criar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'criar') {
    $arquivo = null;
    if (isset($_FILES['arquivo']) && $_FILES['arquivo']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'])) {
            $nome = date('Ymd_His') . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $_FILES['arquivo']['name']);
            move_uploaded_file($_FILES['arquivo']['tmp_name'], "uploads/$nome");
            $arquivo = $nome;
        }
    }
    $stmt = $pdo->prepare("INSERT INTO atestados (aluno_id, data, dias, motivo, observacoes, arquivo) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['aluno_id'], $_POST['data'], $_POST['dias'], $_POST['motivo'], $_POST['observacoes'] ?? '', $arquivo]);
    flashMessage('success', 'Atestado cadastrado!');
    header('Location: atestados.php');
    exit;
}

// Editar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'editar') {
    $stmt = $pdo->prepare("SELECT arquivo FROM atestados WHERE id = ?");
    $stmt->execute([$_POST['id']]);
    $old = $stmt->fetch();

    $arquivo = $old['arquivo'];
    if (isset($_FILES['arquivo']) && $_FILES['arquivo']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'])) {
            if ($arquivo && file_exists("uploads/$arquivo")) unlink("uploads/$arquivo");
            $nome = date('Ymd_His') . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $_FILES['arquivo']['name']);
            move_uploaded_file($_FILES['arquivo']['tmp_name'], "uploads/$nome");
            $arquivo = $nome;
        }
    }
    $stmt = $pdo->prepare("UPDATE atestados SET aluno_id=?, data=?, dias=?, motivo=?, observacoes=?, arquivo=? WHERE id=?");
    $stmt->execute([$_POST['aluno_id'], $_POST['data'], $_POST['dias'], $_POST['motivo'], $_POST['observacoes'] ?? '', $arquivo, $_POST['id']]);
    flashMessage('success', 'Atestado atualizado!');
    header('Location: atestados.php');
    exit;
}

// Excluir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'excluir') {
    $stmt = $pdo->prepare("SELECT arquivo FROM atestados WHERE id = ?");
    $stmt->execute([$_POST['id']]);
    $old = $stmt->fetch();
    if ($old['arquivo'] && file_exists("uploads/{$old['arquivo']}")) unlink("uploads/{$old['arquivo']}");
    $stmt = $pdo->prepare("DELETE FROM atestados WHERE id = ?");
    $stmt->execute([$_POST['id']]);
    flashMessage('success', 'Atestado excluido!');
    header('Location: atestados.php');
    exit;
}

$atestados = $pdo->query("
    SELECT at.*, a.nome as aluno_nome 
    FROM atestados at
    JOIN alunos a ON at.aluno_id = a.id
    ORDER BY at.data DESC
")->fetchAll();

$alunos = $pdo->query("SELECT id, nome FROM alunos WHERE status = 'Ativo' ORDER BY nome")->fetchAll();

include 'header.php';
?>

<div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
    <div class="relative flex-1 max-w-md">
        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input type="text" id="search-atestados" placeholder="Pesquisar..." onkeyup="filtrarAtestados()"
            class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none">
    </div>
    <button onclick="openModal('modal-criar')" class="btn-primary flex items-center gap-2">
        <i class="fas fa-plus"></i> Novo Atestado
    </button>
</div>

<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full" id="tabela-atestados">
            <thead>
                <tr class="bg-slate-50 dark:bg-slate-700/50 text-left text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                    <th class="px-5 py-3">Aluno</th>
                    <th class="px-5 py-3">Data</th>
                    <th class="px-5 py-3">Dias</th>
                    <th class="px-5 py-3">Motivo</th>
                    <th class="px-5 py-3">Arquivo</th>
                    <th class="px-5 py-3 text-right">Acoes</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                <?php if (empty($atestados)): ?>
                <tr><td colspan="6" class="px-5 py-8 text-center text-slate-400">Nenhum atestado cadastrado</td></tr>
                <?php else: foreach ($atestados as $at): ?>
                <tr class="table-row" data-search="<?php echo strtolower($at['aluno_nome'] . ' ' . $at['motivo']); ?>">
                    <td class="px-5 py-3 font-medium"><?php echo htmlspecialchars($at['aluno_nome']); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo date('d/m/Y', strtotime($at['data'])); ?></td>
                    <td class="px-5 py-3 text-sm"><?php echo $at['dias']; ?> dia(s)</td>
                    <td class="px-5 py-3 text-sm"><?php echo htmlspecialchars($at['motivo']); ?></td>
                    <td class="px-5 py-3">
                        <?php if ($at['arquivo']): ?>
                        <a href="uploads/<?php echo htmlspecialchars($at['arquivo']); ?>" target="_blank" class="text-primary-600 hover:text-primary-700 text-sm flex items-center gap-1">
                            <i class="fas fa-file-<?php echo pathinfo($at['arquivo'], PATHINFO_EXTENSION) === 'pdf' ? 'pdf' : 'image'; ?>"></i>
                            Visualizar
                        </a>
                        <?php else: ?>
                        <span class="text-slate-400 text-sm">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3 text-right space-x-2">
                        <button onclick="editarAtestado(<?php echo $at['id']; ?>)" class="text-primary-600 hover:text-primary-700 p-1"><i class="fas fa-edit"></i></button>
                        <button onclick="confirmDelete('Excluir este atestado?', 'form-excluir-<?php echo $at['id']; ?>')" class="text-rose-600 hover:text-rose-700 p-1"><i class="fas fa-trash"></i></button>
                        <form id="form-excluir-<?php echo $at['id']; ?>" method="POST" class="hidden">
                            <input type="hidden" name="acao" value="excluir">
                            <input type="hidden" name="id" value="<?php echo $at['id']; ?>">
                        </form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Criar -->
<div id="modal-criar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Novo Atestado</h3>
            <button onclick="closeModal('modal-criar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" enctype="multipart/form-data" class="space-y-4">
            <input type="hidden" name="acao" value="criar">
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Aluno</label>
                <select name="aluno_id" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <option value="">Selecione...</option>
                    <?php foreach ($alunos as $a): ?>
                    <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['nome']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Data</label>
                    <input type="date" name="data" required value="<?php echo date('Y-m-d'); ?>" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Dias</label>
                    <input type="number" name="dias" required min="1" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Motivo</label>
                <input type="text" name="motivo" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Anexo (PDF, JPG, PNG)</label>
                <input type="file" name="arquivo" accept=".pdf,.jpg,.jpeg,.png" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacoes</label>
                <textarea name="observacoes" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-criar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Salvar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Editar -->
<div id="modal-editar" class="modal">
    <div class="modal-content bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-lg mx-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
        <div class="flex items-center justify-between mb-5">
            <h3 class="text-xl font-bold">Editar Atestado</h3>
            <button onclick="closeModal('modal-editar')" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times text-lg"></i></button>
        </div>
        <form method="POST" enctype="multipart/form-data" class="space-y-4" id="form-editar">
            <input type="hidden" name="acao" value="editar">
            <input type="hidden" name="id" id="edit-id">
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Aluno</label>
                <select name="aluno_id" id="edit-aluno" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                    <?php foreach ($alunos as $a): ?>
                    <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['nome']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Data</label>
                    <input type="date" name="data" id="edit-data" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Dias</label>
                    <input type="number" name="dias" id="edit-dias" required min="1" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Motivo</label>
                <input type="text" name="motivo" id="edit-motivo" required class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Novo Anexo (deixe em branco para manter)</label>
                <input type="file" name="arquivo" accept=".pdf,.jpg,.jpeg,.png" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Observacoes</label>
                <textarea name="observacoes" id="edit-obs" rows="2" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 outline-none focus:ring-2 focus:ring-primary-500"></textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="button" onclick="closeModal('modal-editar')" class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">Cancelar</button>
                <button type="submit" class="flex-1 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-xl transition-colors"><i class="fas fa-save mr-2"></i>Atualizar</button>
            </div>
        </form>
    </div>
</div>

<script>
const atestadosData = <?php echo json_encode($atestados); ?>;
function editarAtestado(id) {
    const at = atestadosData.find(x => x.id == id);
    if (at) {
        document.getElementById('edit-id').value = at.id;
        document.getElementById('edit-aluno').value = at.aluno_id;
        document.getElementById('edit-data').value = at.data;
        document.getElementById('edit-dias').value = at.dias;
        document.getElementById('edit-motivo').value = at.motivo;
        document.getElementById('edit-obs').value = at.observacoes || '';
        openModal('modal-editar');
    }
}
function filtrarAtestados() {
    const termo = document.getElementById('search-atestados').value.toLowerCase();
    document.querySelectorAll('#tabela-atestados tbody tr').forEach(row => {
        const s = row.getAttribute('data-search');
        row.style.display = !s || s.includes(termo) ? '' : 'none';
    });
}
</script>

<?php include 'footer.php'; ?>
