<?php
require_once 'config.php';
requireLogin();

$turmas = $pdo->query("SELECT * FROM turmas ORDER BY nome")->fetchAll();
$alunos = $pdo->query("SELECT id, nome FROM alunos WHERE status = 'Ativo' ORDER BY nome")->fetchAll();

include 'header.php';
?>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center text-primary-600 mb-4">
            <i class="fas fa-users text-xl"></i>
        </div>
        <h3 class="font-bold text-lg mb-2">Lista de Alunos</h3>
        <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">Relatorio completo de alunos por turma e status</p>
        <form action="relatorio_alunos.php" target="_blank" class="space-y-3">
            <select name="turma_id" class="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-sm">
                <option value="">Todas as turmas</option>
                <?php foreach ($turmas as $t): ?>
                <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['nome']); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="status" class="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-sm">
                <option value="">Todos os status</option>
                <option value="Ativo">Ativo</option>
                <option value="Inativo">Inativo</option>
                <option value="Transferido">Transferido</option>
            </select>
            <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white py-2 rounded-lg text-sm transition-colors">
                <i class="fas fa-print mr-2"></i>Gerar Relatorio
            </button>
        </form>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center text-amber-600 mb-4">
            <i class="fas fa-star text-xl"></i>
        </div>
        <h3 class="font-bold text-lg mb-2">Notas</h3>
        <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">Relatorio de notas com medias e situacao</p>
        <form action="relatorio_notas.php" target="_blank" class="space-y-3">
            <select name="aluno_id" required class="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-sm">
                <option value="">Selecione o aluno...</option>
                <?php foreach ($alunos as $a): ?>
                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['nome']); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="w-full bg-amber-500 hover:bg-amber-600 text-white py-2 rounded-lg text-sm transition-colors">
                <i class="fas fa-print mr-2"></i>Gerar Relatorio
            </button>
        </form>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl flex items-center justify-center text-emerald-600 mb-4">
            <i class="fas fa-clipboard-check text-xl"></i>
        </div>
        <h3 class="font-bold text-lg mb-2">Frequencia</h3>
        <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">Relatorio de presencas e faltas do aluno</p>
        <form action="relatorio_frequencia.php" target="_blank" class="space-y-3">
            <select name="aluno_id" required class="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-sm">
                <option value="">Selecione o aluno...</option>
                <?php foreach ($alunos as $a): ?>
                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['nome']); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-2 rounded-lg text-sm transition-colors">
                <i class="fas fa-print mr-2"></i>Gerar Relatorio
            </button>
        </form>
    </div>

    <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 card-hover">
        <div class="w-12 h-12 bg-violet-100 dark:bg-violet-900/30 rounded-xl flex items-center justify-center text-violet-600 mb-4">
            <i class="fas fa-file-medical text-xl"></i>
        </div>
        <h3 class="font-bold text-lg mb-2">Atestados</h3>
        <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">Relatorio de atestados por aluno</p>
        <form action="relatorio_atestados.php" target="_blank" class="space-y-3">
            <select name="aluno_id" required class="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-sm">
                <option value="">Selecione o aluno...</option>
                <?php foreach ($alunos as $a): ?>
                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['nome']); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="w-full bg-violet-500 hover:bg-violet-600 text-white py-2 rounded-lg text-sm transition-colors">
                <i class="fas fa-print mr-2"></i>Gerar Relatorio
            </button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
