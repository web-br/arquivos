<?php
require_once 'config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senha_atual = $_POST['senha_atual'] ?? '';
    $nova_senha = $_POST['nova_senha'] ?? '';
    $confirmar = $_POST['confirmar'] ?? '';

    if ($nova_senha !== $confirmar) {
        flashMessage('error', 'As senhas nao coincidem!');
    } else {
        $stmt = $pdo->prepare("SELECT senha_hash FROM usuarios WHERE id = ?");
        $stmt->execute([$_SESSION['usuario_id']]);
        $user = $stmt->fetch();

        if ($user['senha_hash'] !== hashSenha($senha_atual)) {
            flashMessage('error', 'Senha atual incorreta!');
        } else {
            $stmt = $pdo->prepare("UPDATE usuarios SET senha_hash = ? WHERE id = ?");
            $stmt->execute([hashSenha($nova_senha), $_SESSION['usuario_id']]);
            flashMessage('success', 'Senha alterada com sucesso!');
            header('Location: dashboard.php');
            exit;
        }
    }
}

include 'header.php';
?>

<div class="max-w-md mx-auto">
    <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 p-6">
        <div class="flex items-center gap-3 mb-6">
            <div class="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center text-primary-600">
                <i class="fas fa-key"></i>
            </div>
            <h2 class="text-xl font-bold">Alterar Senha</h2>
        </div>

        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Senha Atual</label>
                <input type="password" name="senha_atual" required
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nova Senha</label>
                <input type="password" name="nova_senha" required
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Confirmar Nova Senha</label>
                <input type="password" name="confirmar" required
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none">
            </div>
            <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 rounded-xl transition-colors">
                <i class="fas fa-save mr-2"></i>Salvar Alteracoes
            </button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
